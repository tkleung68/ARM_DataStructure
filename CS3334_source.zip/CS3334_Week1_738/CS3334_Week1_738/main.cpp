#include <iostream>
using namespace std;


int main(){
    int num;
    int Fibonacci[1001] = {0,1};
    
    
    for(int i=2;i<1001;i++){
        Fibonacci[i] = (Fibonacci[i-1] + Fibonacci[i-2])%10;
    }
    while(cin >> num){
    cout << Fibonacci[num] << endl;
    }
    return 0;
}
