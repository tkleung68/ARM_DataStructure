
#include <iostream>
#include <string>
using namespace std;

void largestSub(string str){
    
    char temp[55];
    char result[55];
    int position =0;
    int count = 1;
    
    result[0] = str.at(0);
    for(int i=0;i<str.length();i++){
        temp[i] = str.at(i);
        if(result[0]<temp[i]){
            result[0] = temp[i];
            position = i;
        }
    }

    while(position!=str.length()-1){
        char max = 96;
        for(int i=position+1;i<str.length();i++){
            
            if(max<temp[i]){
                max = temp[i];
                position = i;
            }
        }
        result[count] = max;
        count++;
    }
    result[count] = '\n';
    for(int i=0;i<count;i++){
        cout << result[i];
    }
    cout << endl;
    
}

int main() {
    
    string str;
    int num;
    cin >> num;
    
    
    for(int i=0; i<num;i++){
        cin >> str;
        largestSub(str);
    }

    return 0;
}
