#include <iostream>
using namespace std;

class ListNode{
private:
    int data;
    ListNode *next;
    
    
public:
    ListNode(){
        data = 0;
        next = NULL;
    }
    ListNode(int a){
        data = a;
        next = NULL;
        
    }
    int getData(){
        return data;
    }
    
    friend class List;
    

};

class List{
private:
    ListNode *first;
public:
    List(){
        
    }

    void PrintTag(int x){
        if (first == NULL) {
            return;
        }
        
        ListNode *current = first;
        for(int i=0;i<x-1;i++){
            current = current ->next;
        }
        cout << current->data << endl;
        ChangeReference(x - 1);
    }
    void Add_node(int x){
        
        ListNode *newNode = new ListNode(x);
        
        if (first == NULL) {
            first = newNode;
            return;
        }
        
        ListNode *current = first;
        while (current->next != NULL) {
            current = current->next;
        }
        current->next = newNode;
        newNode->next = NULL;
        
    }
    
    void Insert(int x,int value){
        ListNode *newNode = new ListNode(value);

        if (first == NULL) {
            first = newNode;
            return;
        }

            ListNode *current = first;
            for(int i=0;i<x-1;i++)
                current = current->next;

        newNode->next = current->next;
        current ->next = newNode;
        
        ChangeReference(x);
    }


    void ChangeReference(int x){    //the position x will become the first element

        ListNode *current = first;

        while(current -> next!=NULL){
            current = current -> next;
        }
        current->next = first;
        
        current = first;
        for(int i =0;i<x-1;i++){
            current = current -> next;
        }
        ListNode *newFirst = current;
        first = current -> next;
        newFirst->next = NULL;
    }
    
    void Detele(int x){
        ListNode *current = first;
        for(int i=0;i<x-2;i++){
            current = current->next;
        }
        current->next = current->next->next;
        ChangeReference(x-1);
    }
};



int main() {
    int num , num2, num3;
    List list;
    cin >> num;
    
    for(int i=0;i<num;i++){
        cin >> num2;
        list.Add_node(num2);
    }
    
    cin >> num;
    for(int i=0;i<num;i++){
        cin >> num2;
        switch (num2) {
            case 1:
                cin >> num2 >> num3;
                list.Insert(num2, num3);
                break;
            case 2:
                cin >> num3;
                list.Detele(num3);
                break;
            case 3:
                cin >> num3;
                list.PrintTag(num3);
        }
    }

    
    return 0;
}

