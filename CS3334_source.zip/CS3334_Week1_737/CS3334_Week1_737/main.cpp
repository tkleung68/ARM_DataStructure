#include <iostream>
#include <string>
#include <sstream>
using namespace std;

int main()
{
    string linestr;
    string stored[1000];
    int count_time[1000]={0};
    int position =0;    //

    //不停吸啲input
    while(cin >> linestr){

        
            bool isRepeated = false;    //假設隻野係無重複
            // position=0 姐係第一個字 第一個唔洗check都知唔會重複 只會run一次
            if (position == 0){
                stored[position] = linestr;
                count_time[position]++;
                position++;
                
            }else{
                // for position>0 就會check下linestr有無同之前重覆
                for(int i=0;i<position;i++){
                    if (stored[i]==linestr){
                        isRepeated = true;  //有重複就果個位既time＋1
                        count_time[i]++;
                        }
                    }
                // run 完上面已經知道有無重複
                if(!isRepeated){    //如無重複，即係一隻新字
                    stored[position] = linestr; // 新字會放係stored array入面～
                    count_time[position]++; // time 由0變成1
                    position++; // position都要＋＋
                    
                }
            }
            
            
    }
    

    //sorting
    int temp_ = 0;
    string temp = "";
    for(int i=0;i<position;i++){
        for(int j=i+1;j<position;j++){
            if(stored[i]>stored[j]){
                temp = stored[i];
                stored[i] = stored[j];
                stored[j] = temp;

                temp_= count_time[i];
                count_time[i] = count_time[j];
                count_time[j] = temp_;
            }
        }
    }
    
    // 上一個version 有LengthofArray，但俾我del左。因為position ＝ lenthOfArray
    for(int i=0; i<position;i++){
        cout << stored[i] << " " << count_time[i] << "\n";
    }
    
    return 0;
}


