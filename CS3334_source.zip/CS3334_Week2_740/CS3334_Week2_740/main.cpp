#include <iostream>
using namespace std;


class Listnode{
private:
    int data;
    Listnode *next;
    
public:
    //constructors for Listnode, next will be defined in Class(List)
    Listnode(){
        data = 0;
        next = NULL;
    }
    Listnode(int data){
        this->data = data;
        this->next = NULL;
    }
    friend class List;
};

class List{
private:
    Listnode *first;
public:
    List(){
        this->first = NULL;
    }
    void Add_node(int x){
        Listnode *newNode = new Listnode(x);
        
        if (first == NULL) {
            first = newNode;
            return;
        }
        
        Listnode *current = first;
        while(current->next != NULL){
            current = current->next;
        }
        current->next = newNode;
        newNode->next = NULL;
    }

    void InsertNode(int position, int data){
        Listnode *current = first;
        Listnode *newNode = new Listnode(data);
        if(first==NULL){
            first = newNode;
            return;
        }
        for(int i=0 ;i<position -1;i++){
            current = current->next;
        }
        newNode->next = current->next;
        current->next = newNode;
    }
    
    void DeleteNode(int position){
        Listnode *current = first;
        if(position==1){
            first = current->next;
            return;
        }
            for(int i=0;i<position-2;i++){
                current = current->next;
            }
        
        current->next = current->next->next;
    }
    
    void Reverse(int position1, int position2){

        Listnode *previous = first;
        Listnode *current = first;
        Listnode *last = first;
        Listnode *move = first;
        for(int i=0;i<position1-2;i++){
            previous  = previous->next;
        }
        for(int i=0;i<position2;i++){
            last = last->next;
        }

        for(int i=0;i<position2-1;i++){
            current  = current->next;
        }

        
        for(int i=0;i<position2 - position1;i++){
            move = first;
            for(int j=0;j<position2-i-2;j++){
                move = move->next;
            }
            move->next->next = move;
        }
        if(position1==1){
            move->next = last;
            first = current;
        }else{
        move->next = last;
        previous->next = current;
        }
        
    }
    void PrintTag(int position){
        Listnode *current = first;
        for(int i=0;i<position-1;i++){
            current = current->next;
        }
        cout << current->data << endl;
    }
    
    
};

int main() {
    List list;
    int num, num2,num3;
    cin >> num;
    for(int i=0;i<num;i++){
        cin >> num2;
        list.Add_node(num2);
    }
    cin >> num;
    for(int i=0;i<num;i++){
        cin >> num2;
        switch (num2) {
            case 1:
                cin >> num2 >> num3;
                list.InsertNode(num2, num3);
                break;
            case 2:
                cin >> num2;
                list.DeleteNode(num2);
                break;
            case 3:
                cin >> num2 >> num3;
                list.Reverse(num2,num3);
                break;
            case 4:
                cin >> num2;
                list.PrintTag(num2);
                break;
        }
        
        
    }


    
    return 0;
}
